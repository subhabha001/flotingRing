package com.example.floatingrings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Custom vertical slider for floating overlay control panel.
 * Draws a clean modern vertical track, thumb, and emits progress 0..100.
 */
class VerticalSlider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var progress: Int = 100 // 0 to 100
    private var onProgressChangeListener: ((Int) -> Unit)? = null

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#334155")
        style = Paint.Style.FILL
    }

    private val activeTrackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.FILL
    }

    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val thumbBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val trackRect = RectF()
    private val activeTrackRect = RectF()

    fun setProgress(value: Int, notify: Boolean = false) {
        val clamped = value.coerceIn(0, 100)
        if (progress != clamped) {
            progress = clamped
            invalidate()
            if (notify) {
                onProgressChangeListener?.invoke(progress)
            }
        }
    }

    fun getProgress(): Int = progress

    fun setOnProgressChangeListener(listener: (Int) -> Unit) {
        this.onProgressChangeListener = listener
    }

    fun setActiveColor(color: Int) {
        activeTrackPaint.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val trackWidth = 8f * resources.displayMetrics.density
        val trackRadius = trackWidth / 2f

        val thumbRadius = 9f * resources.displayMetrics.density
        val topPadding = thumbRadius
        val bottomPadding = thumbRadius
        val usableHeight = (h - topPadding - bottomPadding).coerceAtLeast(1f)

        val left = (w - trackWidth) / 2f
        val right = left + trackWidth

        // Full background track
        trackRect.set(left, topPadding, right, h - bottomPadding)
        canvas.drawRoundRect(trackRect, trackRadius, trackRadius, trackPaint)

        // Calculate thumb Y position (progress 100 at top, 0 at bottom)
        val progressFraction = progress / 100f
        val thumbY = (h - bottomPadding) - (progressFraction * usableHeight)

        // Active bottom-to-thumb track
        activeTrackRect.set(left, thumbY, right, h - bottomPadding)
        canvas.drawRoundRect(activeTrackRect, trackRadius, trackRadius, activeTrackPaint)

        // Thumb knob
        val thumbX = w / 2f
        canvas.drawCircle(thumbX, thumbY, thumbRadius, thumbPaint)
        canvas.drawCircle(thumbX, thumbY, thumbRadius, thumbBorderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val thumbRadius = 9f * resources.displayMetrics.density
                val topPadding = thumbRadius
                val bottomPadding = thumbRadius
                val usableHeight = (height - topPadding - bottomPadding).coerceAtLeast(1f)

                // progress 100 at top, 0 at bottom
                val clampedY = event.y.coerceIn(topPadding, height - bottomPadding)
                val fraction = 1f - ((clampedY - topPadding) / usableHeight)
                val newProgress = (fraction * 100).toInt().coerceIn(0, 100)

                if (newProgress != progress) {
                    progress = newProgress
                    invalidate()
                    onProgressChangeListener?.invoke(progress)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}

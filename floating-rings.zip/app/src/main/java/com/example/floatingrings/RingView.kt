package com.example.floatingrings

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class RingView(context: Context, color: Int) : View(context) {
    private var baseColor: Int = color
    private var ringAlpha: Int = 255

    private val paint = Paint().apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeWidth = 8f
        isAntiAlias = true
    }

    init {
        updatePaintColor()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val radius = (width.coerceAtMost(height) / 2f) - (paint.strokeWidth / 2f)
        if (radius > 0) {
            canvas.drawCircle(width / 2f, height / 2f, radius, paint)
        }
    }

    fun setRingColor(newColor: Int) {
        baseColor = newColor
        updatePaintColor()
    }

    /**
     * Set alpha transparency in range 0..255
     */
    fun setRingAlpha(alpha: Int) {
        ringAlpha = alpha.coerceIn(0, 255)
        updatePaintColor()
    }

    fun getRingAlpha(): Int = ringAlpha

    private fun updatePaintColor() {
        val red = Color.red(baseColor)
        val green = Color.green(baseColor)
        val blue = Color.blue(baseColor)
        paint.color = Color.argb(ringAlpha, red, green, blue)
        invalidate()
    }

    fun setStrokeWidthPx(widthPx: Float) {
        paint.strokeWidth = widthPx
        invalidate()
    }
}

package com.example.floatingrings

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FloatingService : Service() {

    companion object {
        const val CHANNEL_ID = "floating_rings_channel"
        const val NOTIFICATION_ID = 1001

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()
    }

    private lateinit var windowManager: WindowManager

    // ৩টি রিংয়ের ভিউ ও প্যারামস
    private val rings = mutableListOf<RingView>()
    private val ringParams = mutableListOf<WindowManager.LayoutParams>()
    private val ringAlphas = mutableListOf(255, 255, 255) // Alpha per ring 0..255
    private var activeRingIndex = 0
    private var isLocked = false

    private lateinit var controlView: LinearLayout
    private lateinit var controlParams: WindowManager.LayoutParams
    private lateinit var statusText: TextView
    private lateinit var alphaPercentText: TextView
    private lateinit var verticalAlphaSlider: VerticalSlider

    private val colors = listOf(
        Color.rgb(255, 59, 48),  // Red
        Color.rgb(0, 230, 118),  // Green
        Color.rgb(0, 229, 255)   // Cyan
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        _isServiceRunning.value = true
        startForegroundSafely()

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // ৩টি রিং তৈরি
        for (i in 0..2) {
            val ring = RingView(this, colors[i])
            ring.setRingAlpha(ringAlphas[i])
            val params = WindowManager.LayoutParams(
                150, 150,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 100 + (i * 140)
                y = 300
            }

            // Direct touch-to-drag support for natural positioning
            val ringIndex = i
            ring.setOnTouchListener(object : View.OnTouchListener {
                private var initialX = 0
                private var initialY = 0
                private var initialTouchX = 0f
                private var initialTouchY = 0f

                override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                    if (isLocked) return false
                    when (event?.action) {
                        MotionEvent.ACTION_DOWN -> {
                            activeRingIndex = ringIndex
                            updateStatus()
                            syncSliderWithActiveRing()
                            initialX = params.x
                            initialY = params.y
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params.x = initialX + (event.rawX - initialTouchX).toInt()
                            params.y = initialY + (event.rawY - initialTouchY).toInt()
                            try {
                                windowManager.updateViewLayout(ring, params)
                            } catch (_: Exception) {}
                            return true
                        }
                    }
                    return false
                }
            })

            rings.add(ring)
            ringParams.add(params)
            try {
                windowManager.addView(ring, params)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        setupControlPanel(overlayType)
    }

    private fun startForegroundSafely() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Floating Rings Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows floating rings overlay status"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)

            val openIntent = packageManager.getLaunchIntentForPackage(packageName)
            val pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Floating Rings সক্রিয়")
                .setContentText("ফ্লোটিং রিং ও কন্ট্রোল প্যানেল স্ক্রিনে চলছে")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build()

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun setupControlPanel(overlayType: Int) {
        val density = resources.displayMetrics.density

        val panelBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 24f * density
            setColor(Color.parseColor("#EE121826")) // Sleek semi-transparent dark slate
            setStroke((1.5f * density).toInt(), Color.parseColor("#334155"))
        }

        controlView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            val pad = (12 * density).toInt()
            setPadding(pad, pad, pad, pad)
            elevation = 16f * density
        }

        // Title and drag handle
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val padBottom = (4 * density).toInt()
            setPadding(0, 0, 0, padBottom)
        }

        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            text = "রিং: ১ (লাল) | আনলকড"
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val dragIndicator = TextView(this).apply {
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12f
            text = "⠿ টানুন"
        }

        headerLayout.addView(statusText)
        headerLayout.addView(dragIndicator)

        // Make control panel draggable on screen
        headerLayout.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                when (event?.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = controlParams.x
                        initialY = controlParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        controlParams.x = initialX - (event.rawX - initialTouchX).toInt()
                        controlParams.y = initialY - (event.rawY - initialTouchY).toInt()
                        try {
                            windowManager.updateViewLayout(controlView, controlParams)
                        } catch (_: Exception) {}
                        return true
                    }
                }
                return false
            }
        })

        // Helper to style buttons
        fun createStyledButton(label: String, bgColor: Int, textColor: Int = Color.WHITE): Button {
            return Button(this).apply {
                text = label
                textSize = 12.5f
                isAllCaps = false
                setTextColor(textColor)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 12f * density
                    setColor(bgColor)
                }
                val margin = (3 * density).toInt()
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (38 * density).toInt()
                ).apply {
                    setMargins(0, margin, 0, margin)
                }
                layoutParams = lp
            }
        }

        // রিং সিলেক্ট বাটন
        val selectBtn = createStyledButton("রিং পরিবর্তন", Color.parseColor("#2563EB")).apply {
            setOnClickListener {
                activeRingIndex = (activeRingIndex + 1) % 3
                updateStatus()
                syncSliderWithActiveRing()
            }
        }

        // Content layout: Left controls + Right vertical alpha slider
        val bodyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Left column for size, move, lock buttons
        val leftColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        // সাইজ কন্ট্রোল বাটন রো
        val sizeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val margin = (2 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, margin, 0, margin)
            }
        }

        val sizeUpBtn = createStyledButton("সাইজ +", Color.parseColor("#334155")).apply {
            layoutParams = LinearLayout.LayoutParams(0, (36 * density).toInt(), 1f).apply {
                rightMargin = (2 * density).toInt()
            }
            setOnClickListener {
                if (!isLocked) {
                    val p = ringParams[activeRingIndex]
                    p.width += 20
                    p.height += 20
                    windowManager.updateViewLayout(rings[activeRingIndex], p)
                }
            }
        }

        val sizeDownBtn = createStyledButton("সাইজ -", Color.parseColor("#334155")).apply {
            layoutParams = LinearLayout.LayoutParams(0, (36 * density).toInt(), 1f).apply {
                leftMargin = (2 * density).toInt()
            }
            setOnClickListener {
                if (!isLocked && ringParams[activeRingIndex].width > 40) {
                    val p = ringParams[activeRingIndex]
                    p.width -= 20
                    p.height -= 20
                    windowManager.updateViewLayout(rings[activeRingIndex], p)
                }
            }
        }
        sizeRow.addView(sizeUpBtn)
        sizeRow.addView(sizeDownBtn)

        // ডানে-বামে-উপরে-নিচে মুভ বাটন গ্রিড
        val moveUpBtn = createStyledButton("▲ উপরে", Color.parseColor("#1E293B")).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (34 * density).toInt()
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (2 * density).toInt())
            }
            setOnClickListener { moveRing(0, -30) }
        }

        val moveMidRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val margin = (2 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, margin, 0, margin)
            }
        }

        val moveLeftBtn = createStyledButton("◀ বাঁয়ে", Color.parseColor("#1E293B")).apply {
            layoutParams = LinearLayout.LayoutParams(0, (34 * density).toInt(), 1f).apply {
                rightMargin = (2 * density).toInt()
            }
            setOnClickListener { moveRing(-30, 0) }
        }

        val moveRightBtn = createStyledButton("▶ ডানে", Color.parseColor("#1E293B")).apply {
            layoutParams = LinearLayout.LayoutParams(0, (34 * density).toInt(), 1f).apply {
                leftMargin = (2 * density).toInt()
            }
            setOnClickListener { moveRing(30, 0) }
        }
        moveMidRow.addView(moveLeftBtn)
        moveMidRow.addView(moveRightBtn)

        val moveDownBtn = createStyledButton("▼ নিচে", Color.parseColor("#1E293B")).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (34 * density).toInt()
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (2 * density).toInt())
            }
            setOnClickListener { moveRing(0, 30) }
        }

        leftColumn.addView(sizeRow)
        leftColumn.addView(moveUpBtn)
        leftColumn.addView(moveMidRow)
        leftColumn.addView(moveDownBtn)

        // Right column: Vertical Alpha Slider container
        val rightSliderColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            val marginStart = (10 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(
                (46 * density).toInt(),
                LinearLayout.LayoutParams.MATCH_PARENT
            ).apply {
                setMargins(marginStart, (2 * density).toInt(), 0, (2 * density).toInt())
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 14f * density
                setColor(Color.parseColor("#1A2333"))
                setStroke((1f * density).toInt(), Color.parseColor("#334155"))
            }
            val pad = (6 * density).toInt()
            setPadding(pad, pad, pad, pad)
        }

        val alphaTitleText = TextView(this).apply {
            text = "আলফা"
            textSize = 10f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
        }

        alphaPercentText = TextView(this).apply {
            text = "100%"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            val margin = (2 * density).toInt()
            setPadding(0, 0, 0, margin)
        }

        verticalAlphaSlider = VerticalSlider(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                (32 * density).toInt(),
                (120 * density).toInt()
            )
            val currentAlpha = ringAlphas[activeRingIndex]
            val initialProgress = (currentAlpha * 100 / 255)
            setProgress(initialProgress)
            setActiveColor(colors[activeRingIndex])

            setOnProgressChangeListener { progress ->
                val newAlpha = (progress * 255 / 100).coerceIn(0, 255)
                ringAlphas[activeRingIndex] = newAlpha
                rings[activeRingIndex].setRingAlpha(newAlpha)
                alphaPercentText.text = "$progress%"
            }
        }

        rightSliderColumn.addView(alphaTitleText)
        rightSliderColumn.addView(alphaPercentText)
        rightSliderColumn.addView(verticalAlphaSlider)

        bodyRow.addView(leftColumn)
        bodyRow.addView(rightSliderColumn)

        // লক/আনলক সুইচ বাটন
        val lockBtn = createStyledButton("লক/আনলক", Color.parseColor("#D97706")).apply {
            setOnClickListener {
                isLocked = !isLocked
                updateStatus()
            }
        }

        // ক্লোজ বাটন
        val closeBtn = createStyledButton("বন্ধ করুন", Color.parseColor("#DC2626")).apply {
            setOnClickListener { stopSelf() }
        }

        controlView.addView(headerLayout)
        controlView.addView(selectBtn)
        controlView.addView(bodyRow)
        controlView.addView(lockBtn)
        controlView.addView(closeBtn)

        controlParams = WindowManager.LayoutParams(
            (210 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = 30
            y = 100
        }

        try {
            windowManager.addView(controlView, controlParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun syncSliderWithActiveRing() {
        if (::verticalAlphaSlider.isInitialized && ::alphaPercentText.isInitialized) {
            val alpha = ringAlphas[activeRingIndex]
            val percent = (alpha * 100 / 255).coerceIn(0, 100)
            verticalAlphaSlider.setProgress(percent)
            verticalAlphaSlider.setActiveColor(colors[activeRingIndex])
            alphaPercentText.text = "$percent%"
        }
    }

    private fun updateStatus() {
        val ringColorName = when (activeRingIndex) {
            0 -> "১ (লাল)"
            1 -> "২ (সবুজ)"
            2 -> "৩ (সায়ান)"
            else -> "${activeRingIndex + 1}"
        }
        val lockStatus = if (isLocked) "লকড" else "আনলকড"
        statusText.text = "রিং: $ringColorName | $lockStatus"
    }

    private fun moveRing(dx: Int, dy: Int) {
        if (!isLocked && activeRingIndex in ringParams.indices) {
            val p = ringParams[activeRingIndex]
            p.x += dx
            p.y += dy
            try {
                windowManager.updateViewLayout(rings[activeRingIndex], p)
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false
        rings.forEach {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        rings.clear()
        ringParams.clear()
        if (::controlView.isInitialized) {
            try {
                windowManager.removeView(controlView)
            } catch (_: Exception) {}
        }
    }
}

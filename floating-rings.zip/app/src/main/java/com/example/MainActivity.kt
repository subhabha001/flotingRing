package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.floatingrings.FloatingService
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                FloatingRingsScreen(
                    onStartFloating = { finishOnStart ->
                        checkOverlayPermissionAndStart(finishOnStart)
                    },
                    onStopFloating = {
                        stopFloatingService()
                    },
                    onOpenPermissionSettings = {
                        openOverlayPermissionSettings()
                    }
                )
            }
        }
    }

    private fun checkOverlayPermissionAndStart(finishOnStart: Boolean) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "অনুগ্রহ করে ওভারলে পারমিশন দিন", Toast.LENGTH_LONG).show()
            openOverlayPermissionSettings()
        } else {
            val intent = Intent(this, FloatingService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startService(intent)
            } else {
                startService(intent)
            }
            Toast.makeText(this, "ফ্লোটিং রিং চালু হয়েছে!", Toast.LENGTH_SHORT).show()
            if (finishOnStart) {
                finish() // অ্যাপ স্ক্রিন বন্ধ হয়ে যাবে, ওভারলে ব্যাকগ্রাউন্ডে চলতে থাকবে
            }
        }
    }

    private fun stopFloatingService() {
        val intent = Intent(this, FloatingService::class.java)
        stopService(intent)
        Toast.makeText(this, "ফ্লোটিং রিং বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun openOverlayPermissionSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingRingsScreen(
    onStartFloating: (finishOnStart: Boolean) -> Unit,
    onStopFloating: () -> Unit,
    onOpenPermissionSettings: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val isServiceRunning by FloatingService.isServiceRunning.collectAsStateWithLifecycle()

    var hasOverlayPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
        )
    }

    var finishOnStart by remember { mutableStateOf(false) }

    // Re-check permission when resuming app from Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    Settings.canDrawOverlays(context)
                } else true
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Notification permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* Handled gracefully */ }
    )

    DisposableEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        onDispose {}
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0F172A))
                                .border(2.dp, Color(0xFF00E5FF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFF3B30))
                            )
                        }
                        Text(
                            text = stringResource(R.string.app_name),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isServiceRunning) Color(0xFF0F2D1F) else Color(0xFF1E293B)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                if (isServiceRunning) Color(0xFF059669).copy(alpha = 0.2f)
                                else Color(0xFF334155).copy(alpha = 0.4f)
                            )
                            .border(
                                2.dp,
                                if (isServiceRunning) Color(0xFF10B981) else Color(0xFF64748B),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isServiceRunning) Icons.Default.CheckCircle else Icons.Default.Layers,
                            contentDescription = "Status",
                            tint = if (isServiceRunning) Color(0xFF10B981) else Color(0xFF94A3B8),
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isServiceRunning) "ফ্লোটিং রিং সক্রিয় রয়েছে" else "ফ্লোটিং রিং প্রস্তুত",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isServiceRunning) stringResource(R.string.service_running_desc)
                        else stringResource(R.string.service_stopped_desc),
                        fontSize = 13.sp,
                        color = Color(0xFFCBD5E1),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Primary Start Action Button
                    Button(
                        onClick = { onStartFloating(finishOnStart) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("start_floating_rings_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2563EB),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.start_floating_rings),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    AnimatedVisibility(visible = isServiceRunning) {
                        Column {
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = onStopFloating,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("stop_floating_rings_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFEF4444)
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stringResource(R.string.stop_floating_rings),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Finish on start toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "চালু করার পর অ্যাপ বন্ধ করুন (Finish app)",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Switch(
                            checked = finishOnStart,
                            onCheckedChange = { finishOnStart = it },
                            modifier = Modifier.testTag("finish_on_start_switch")
                        )
                    }
                }
            }

            // System Permission Status Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("permission_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (hasOverlayPermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (hasOverlayPermission) Color(0xFF10B981) else Color(0xFFF59E0B)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.overlay_permission_title),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (hasOverlayPermission) stringResource(R.string.overlay_permission_granted)
                                else stringResource(R.string.overlay_permission_required),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (!hasOverlayPermission) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onOpenPermissionSettings,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("grant_permission_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFD97706)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = stringResource(R.string.grant_permission))
                        }
                    }
                }
            }

            // Live Interactive Preview of Rings & Controls
            InteractiveRingsPreviewCard()

            // Instructions / Feature Description Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("guide_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "ফ্লোটিং কন্ট্রোল প্যানেলের গাইড",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                    FeatureGuideItem("রিং ১ (লাল)", "বড় রিং - সূক্ষ্ম পয়েন্টারের জন্য লাল রঙের সার্কেল")
                    FeatureGuideItem("রিং ২ (সবুজ)", "মাঝারি রিং - সবুজ রঙের ভিজ্যুয়াল ফোকাস রিং")
                    FeatureGuideItem("রিং ৩ (সায়ান)", "ছোট রিং - সায়ান নিয়ন মার্কার")
                    FeatureGuideItem("রিং পরিবর্তন", "১, ২, ৩ নম্বর রিং পর্যায়ক্রমে সিলেক্ট করুন")
                    FeatureGuideItem("ভার্টিক্যাল স্লাইডার", "সিলেক্ট করা রিংয়ের স্বচ্ছতা (Alpha 0% থেকে 100%) নিয়ন্ত্রণ করুন")
                    FeatureGuideItem("সাইজ + / -", "সিলেক্ট করা রিংয়ের আকার বড় বা ছোট করুন")
                    FeatureGuideItem("▲ ▼ ◀ ▶", "চারটি ডিরেকশনে রিংকে ইচ্ছামতো স্থানান্তর করুন")
                    FeatureGuideItem("লক/আনলক", "রিং মুভমেন্ট সাময়িকভাবে লক বা আনলক করুন")
                    FeatureGuideItem("টানুন (Drag)", "রিং বা কন্ট্রোল প্যানেল টাচ করে যেকোনো স্থানে টেনে নিন")
                }
            }
        }
    }
}

@Composable
fun InteractiveRingsPreviewCard() {
    var previewActiveRing by remember { mutableIntStateOf(0) }
    var ring1Radius by remember { mutableFloatStateOf(44f) }
    var ring2Radius by remember { mutableFloatStateOf(36f) }
    var ring3Radius by remember { mutableFloatStateOf(28f) }
    var ring1Alpha by remember { mutableFloatStateOf(1f) }
    var ring2Alpha by remember { mutableFloatStateOf(1f) }
    var ring3Alpha by remember { mutableFloatStateOf(1f) }
    var ring1X by remember { mutableFloatStateOf(0f) }
    var ring1Y by remember { mutableFloatStateOf(0f) }
    var isPreviewLocked by remember { mutableStateOf(false) }

    val ringColors = listOf(
        Color(0xFFFF3B30), // Red
        Color(0xFF00E676), // Green
        Color(0xFF00E5FF)  // Cyan
    )

    val currentAlpha = when (previewActiveRing) {
        0 -> ring1Alpha
        1 -> ring2Alpha
        else -> ring3Alpha
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("rings_preview_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0B1120)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "রিং প্রিভিউ (Interactive Preview)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.White
                )
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isPreviewLocked) Color(0xFFB45309) else Color(0xFF1E293B)
                ) {
                    Text(
                        text = if (isPreviewLocked) "লকড" else "সক্রিয়: রিং ${previewActiveRing + 1} (${(currentAlpha * 100).toInt()}%)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Canvas preview
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF070B14))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val centerX = size.width / 2f
                    val centerY = size.height / 2f

                    // Ring 1 (Red)
                    drawCircle(
                        color = ringColors[0].copy(alpha = ring1Alpha),
                        radius = ring1Radius * density,
                        center = androidx.compose.ui.geometry.Offset(
                            centerX + ring1X * density,
                            centerY + ring1Y * density
                        ),
                        style = Stroke(width = if (previewActiveRing == 0) 5f * density else 3f * density)
                    )

                    // Ring 2 (Green)
                    drawCircle(
                        color = ringColors[1].copy(alpha = ring2Alpha),
                        radius = ring2Radius * density,
                        center = androidx.compose.ui.geometry.Offset(centerX - 40 * density, centerY),
                        style = Stroke(width = if (previewActiveRing == 1) 5f * density else 3f * density)
                    )

                    // Ring 3 (Cyan)
                    drawCircle(
                        color = ringColors[2].copy(alpha = ring3Alpha),
                        radius = ring3Radius * density,
                        center = androidx.compose.ui.geometry.Offset(centerX + 40 * density, centerY),
                        style = Stroke(width = if (previewActiveRing == 2) 5f * density else 3f * density)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Alpha slider row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "স্বচ্ছতা (Alpha):",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
                androidx.compose.material3.Slider(
                    value = currentAlpha,
                    onValueChange = { newAlpha ->
                        when (previewActiveRing) {
                            0 -> ring1Alpha = newAlpha
                            1 -> ring2Alpha = newAlpha
                            2 -> ring3Alpha = newAlpha
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = androidx.compose.material3.SliderDefaults.colors(
                        thumbColor = ringColors[previewActiveRing],
                        activeTrackColor = ringColors[previewActiveRing]
                    )
                )
                Text(
                    text = "${(currentAlpha * 100).toInt()}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Mini in-app controls to test preview
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { previewActiveRing = (previewActiveRing + 1) % 3 },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text("রিং পরিবর্তন", fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        if (!isPreviewLocked) {
                            when (previewActiveRing) {
                                0 -> ring1Radius = (ring1Radius + 4f).coerceAtMost(60f)
                                1 -> ring2Radius = (ring2Radius + 4f).coerceAtMost(60f)
                                2 -> ring3Radius = (ring3Radius + 4f).coerceAtMost(60f)
                            }
                        }
                    },
                    modifier = Modifier.weight(0.7f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text("সাইজ +", fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        if (!isPreviewLocked) {
                            when (previewActiveRing) {
                                0 -> ring1Radius = (ring1Radius - 4f).coerceAtLeast(16f)
                                1 -> ring2Radius = (ring2Radius - 4f).coerceAtLeast(16f)
                                2 -> ring3Radius = (ring3Radius - 4f).coerceAtLeast(16f)
                            }
                        }
                    },
                    modifier = Modifier.weight(0.7f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text("সাইজ -", fontSize = 12.sp)
                }

                Button(
                    onClick = { isPreviewLocked = !isPreviewLocked },
                    modifier = Modifier.weight(0.8f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPreviewLocked) Color(0xFFB45309) else Color(0xFF475569)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Text(if (isPreviewLocked) "আনলক" else "লক", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun FeatureGuideItem(title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "•",
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            fontSize = 14.sp
        )
        Column {
            Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(
                text = desc,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
